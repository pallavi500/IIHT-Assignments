package com.in28minutes.jpa.hibernate.demo.entity;

public enum ReviewRating {
	ONE,TWO,THREE,FOUR,FIVE
}
