package com.in28minutes.jpa.hibernate.demo.entity;

import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;

import org.hibernate.annotations.CreationTimestamp;

import org.hibernate.annotations.UpdateTimestamp;

@Entity
//@Inheritance(strategy=InheritanceType.JOINED)
@DiscriminatorColumn(name="EmployeeType")
public abstract class Employee {
	@GeneratedValue
	@Id
	public Long id;
	
	@Column(nullable=false)
	public String name;
	 public Employee(){
		 
	 }
	
	public Employee(String name) {
		// TODO Auto-generated constructor stub
		this.name=name;
	}

	public Long getId() {
		return id;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + "]";
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	

}