insert into course(id,name,created_date,last_updated_date,is_deleted) values(10001,'JPA in 50 steps',sysdate(),sysdate(),false);
insert into course(id,name,created_date,last_updated_date,is_deleted) values(10002,'Spring in 100 steps',sysdate(),sysdate(),false);
insert into course(id,name,created_date,last_updated_date,is_deleted) values(10003,'Spring boot in 150 steps',sysdate(),sysdate(),false);



insert into Passport(id,number) values(40001,'ABC12345');
insert into Passport(id,number) values(40002,'BCD12345');
insert into Passport(id,number) values(40003,'CAB12345');


insert into Student(id,name,passport_id) values(20001,'Ranga',40001);
insert into student(id,name,passport_id) values(20002,'Adam',40002);
insert into student(id,name,passport_id) values(20003,'jane',40003);

insert into review(id,rating,description,course_id) values(50001,'FIVE','Great Courses',10001);
insert into review(id,rating,description,course_id) values(50002,'FOUR','Wonderful Courses',10001);
insert into review(id,rating,description,course_id) values(50003,'FIVE','Awesome Courses',10003);

insert into student_course(student_id,course_id) values(20001,10001);
insert into student_course(student_id,course_id) values(20002,10001);
insert into student_course(student_id,course_id) values(20003,10001);
insert into student_course(student_id,course_id) values(20001,10003);