package com.in28minutes.jpa.hibernate.demo.repository;


import static org.junit.Assert.*;

import java.util.Optional;

import javax.persistence.EntityManager;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.test.context.junit4.SpringRunner;

import com.in28minutes.jpa.hibernate.demo.DemoApplication;
import com.in28minutes.jpa.hibernate.demo.entity.Course;



@RunWith(SpringRunner.class)
@SpringBootTest(classes=DemoApplication.class)
public class CourseSpringDataRepositoryTest {
	private Logger logger= LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	CourseSpringDataRepository cr1;
	
	@Autowired
	EntityManager em;
	
	@Test
	 public void findById_CoursePresent(){
	Optional<Course> courseoptional=cr1.findById(10001L);
	assertTrue(courseoptional.isPresent());
	}
	
	@Test
	 public void findById_CourseNotPresent(){
	Optional<Course> courseoptional=cr1.findById(20001L);
	logger.info("{}",courseoptional.isPresent());
	}
	
	@Test
	public void PlayAroundWithSpringRepository(){
		/*Course course=new Course("Microservicesss!");
		cr1.save(course);
		course.setName("microservcices updated:");
		cr1.save(course);*/
		
		logger.info("courses -> {}",cr1.findAll());
		logger.info("count -> {}",cr1.count());
	}
	
/*	@Test
	public void SortwithRepository(){
		Sort sort
		logger.info("courses -> {}",cr1.findAll(sort));
		logger.info("count -> {}",cr1.count());
	}*/
	
	@Test
	public void TestWithCustomQuery(){
		logger.info("Find By Name -> {}",cr1.findByName("JPA in 50 steps"));
	}

}
